# Jinchao Li's Homepage

## Setup
1. Install the jekyll: `gem install --user-install bundler jekyll`
2. Install the dependencies:
`bundle install --path vendor/bundle`
3. Local preview: run `bundle exec jekyll serve` and visit http://localhost:4000/

© 2021 Jinchao Li. 
Powered by [Jekyll](http://jekyllrb.com/) & [TeXt](https://github.com/kitian616/jekyll-TeXt-theme) Theme.
